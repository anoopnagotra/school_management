from django.apps import AppConfig


class AdminToolsConfig(AppConfig):
    name = 'admin_tools'
